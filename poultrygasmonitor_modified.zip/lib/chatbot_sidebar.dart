
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class ChatBotSidebar extends StatefulWidget {
  @override
  _ChatBotSidebarState createState() => _ChatBotSidebarState();
}

class _ChatBotSidebarState extends State<ChatBotSidebar> {
  final TextEditingController _controller = TextEditingController();
  List<String> _messages = [];

  Future<void> _sendMessage(String message) async {
    // Replace with actual Gemini API endpoint
    final url = Uri.parse('https://gemini.googleapis.com/v1/conversations:generate');
    final headers = {
      'Authorization': 'Bearer YOUR_ACCESS_TOKEN', // Use OAuth2 or API Key
      'Content-Type': 'application/json',
    };
    final body = jsonEncode({"prompt": message});

    final response = await http.post(url, headers: headers, body: body);

    if (response.statusCode == 200) {
      setState(() {
        _messages.add("You: \$message");
        _messages.add("Bot: \${jsonDecode(response.body)['response']}");
      });
    } else {
      print('Request failed with status: \${response.statusCode}');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: Column(
        children: [
          Expanded(
            child: ListView.builder(
              itemCount: _messages.length,
              itemBuilder: (context, index) => ListTile(
                title: Text(_messages[index]),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _controller,
                    decoration: InputDecoration(hintText: "Enter your message"),
                  ),
                ),
                IconButton(
                  icon: Icon(Icons.send),
                  onPressed: () {
                    if (_controller.text.isNotEmpty) {
                      _sendMessage(_controller.text);
                      _controller.clear();
                    }
                  },
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
