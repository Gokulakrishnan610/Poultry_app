import 'package:firebase_core/firebase_core.dart';

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    return FirebaseOptions(
      apiKey: 'AIzaSyAUL78Mpyu4C7-VZWOCf2o1E0V4esMiDxg',
      appId: '1:1088597535090:android:e519007a1585a4c45115eb',
      messagingSenderId: '1088597535090',
      projectId: 'poultry-gas-monitoring',
      storageBucket: 'poultry-gas-monitoring.appspot.com',
      databaseURL: 'https://poultry-gas-monitoring-default-rtdb.firebaseio.com',
    );
  }
}
