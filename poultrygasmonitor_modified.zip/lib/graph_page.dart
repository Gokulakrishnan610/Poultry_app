import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:fl_chart/fl_chart.dart';

class GraphPage extends StatefulWidget {
  @override
  _GraphPageState createState() => _GraphPageState();
}

class _GraphPageState extends State<GraphPage> {
  final DatabaseReference _databaseReference = FirebaseDatabase.instance.ref();
  Map<String, dynamic>? _sensorData;

  @override
  void initState() {
    super.initState();
    _fetchSensorData();
  }

  void _fetchSensorData() async {
    try {
      final snapshot = await _databaseReference.child('sensor_data').get();
      if (snapshot.exists) {
        final data = Map<String, dynamic>.from(snapshot.value as Map);
        setState(() {
          _sensorData = data;
        });
      }
    } catch (error) {
      print('Failed to fetch sensor data: $error');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Gas Levels Graph'),
      ),
      body: _sensorData == null
          ? Center(child: CircularProgressIndicator())
          : Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                children: [
                  _buildGraph('Ammonia Levels', 'ammonia', Colors.orange),
                  SizedBox(height: 20),
                  _buildGraph('Hydrogen Sulfide Levels', 'h2s', Colors.green),
                ],
              ),
            ),
    );
  }

  Widget _buildGraph(String title, String key, Color color) {
    List<FlSpot> chartData = _sensorData!.entries.map((entry) {
      double day = double.parse(entry.key.split('-')[2]);
      double value = entry.value[key]?.toDouble() ?? 0.0;
      return FlSpot(day, value);
    }).toList();

    return Expanded(
      child: Card(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        elevation: 5,
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: Theme.of(context).textTheme.headline6,
              ),
              SizedBox(height: 20),
              Expanded(
                child: LineChart(
                  LineChartData(
                    lineBarsData: [
                      LineChartBarData(
                        spots: chartData,
                        isCurved: true,
                        colors: [color],
                        barWidth: 2,
                        isStrokeCapRound: true,
                        belowBarData: BarAreaData(
                          show: true,
                          colors: [color.withOpacity(0.3)],
                        ),
                        dotData: FlDotData(
                          show: false,
                        ),
                      ),
                    ],
                    titlesData: FlTitlesData(
                      leftTitles: SideTitles(showTitles: true),
                      bottomTitles: SideTitles(showTitles: true),
                    ),
                    axisTitleData: FlAxisTitleData(
                      leftTitle: AxisTitle(showTitle: true, titleText: 'ppm'),
                      bottomTitle: AxisTitle(showTitle: true, titleText: 'Day'),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
