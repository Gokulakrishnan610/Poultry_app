
import 'package:flutter/material.dart';
import 'chatbot_sidebar.dart';  // Import the chatbot sidebar widget

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(title: Text("Poultry Gas Monitor")),
        drawer: ChatBotSidebar(),  // Add the sidebar here
        body: Center(child: Text("Main Content Here")),
      ),
    );
  }
}
