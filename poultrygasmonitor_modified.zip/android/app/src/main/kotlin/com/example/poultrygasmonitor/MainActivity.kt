package com.example.poultrygasmonitor

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
